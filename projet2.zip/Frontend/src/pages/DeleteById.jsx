import React, { useState } from "react";
import API from "../api.js";

export default function DeleteById() {
  const [id, setId] = useState("");
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(false);

  const fetchUser = async (e) => {
    e.preventDefault();
    setUser(null);
    if (!id.trim()) return;
    try {
      setLoading(true);
      const res = await API.get(`/${id.trim()}`);
      setUser(res.data);
    } catch (err) {
      setUser(null);
      alert(err.response?.data?.message || "Utilisateur introuvable");
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async () => {
    if (!user?._id) return;
    const ok = window.confirm(`Supprimer ${user.name} (${user.email}) ?`);
    if (!ok) return;
    try {
      await API.delete(`/${user._id}`);
      alert("Utilisateur supprimé.");
      setUser(null);
      setId("");
    } catch (err) {
      alert(err.response?.data?.message || "Erreur suppression");
    }
  };

  return (
    <div className="p-4 max-w-xl mx-auto">
      <h1 className="text-xl font-bold mb-4">Supprimer par ID (for admins only)</h1>

      <form onSubmit={fetchUser} className="flex gap-2 mb-4">
        <input
          className="flex-1 border p-2"
          placeholder="ID utilisateur"
          value={id}
          onChange={(e) => setId(e.target.value)}
        />
        <button className="px-4 py-2 bg-gray-700 text-white rounded" type="submit">
          Voir
        </button>
      </form>

      {loading && <div>Chargement…</div>}

      {user && (
        <div className="border p-4 rounded bg-white">
          <h2 className="font-semibold mb-2">Informations</h2>
          <ul className="list-disc pl-5">
            <li>ID: {user._id}</li>
            <li>Nom: {user.name}</li>
            <li>Email: {user.email}</li>
            <li>Rôle: {user.role}</li>
            <li>Créé le: {new Date(user.creatAt).toLocaleString()}</li>
          </ul>
          <button
            onClick={handleDelete}
            className="mt-4 px-4 py-2 bg-red-600 text-white rounded"
          >
            Supprimer définitivement
          </button>
        </div>
      )}
    </div>
  );
}