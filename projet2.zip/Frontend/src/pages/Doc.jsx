import React from "react";
import { useAuth } from "../hooks/useAuth.js";

const Code = ({ children }) => (
  <pre className="bg-gray-900 text-green-200 text-sm p-3 rounded overflow-x-auto">
    <code>{children}</code>
  </pre>
);

const Example = ({ title, curl, response }) => (
  <div className="mt-3">
    {title && <div className="text-xs font-semibold mb-1">{title}</div>}
    {curl && (
      <>
        {!title && <div className="text-xs font-semibold mb-1">Exemple curl</div>}
        <Code>{curl}</Code>
      </>
    )}
    {response && (
      <>
        <div className="text-xs font-semibold mb-1 mt-2">Exemple de réponse</div>
        <Code>{response}</Code>
      </>
    )}
  </div>
);

const Section = ({ title, method, route, desc, examples = [] }) => (
  <div className="border rounded p-4 bg-white">
    <h3 className="font-semibold mb-1">{title}</h3>
    <p className="text-sm mb-2 text-gray-700">{desc}</p>
    <div className="text-sm mb-1">
      <span className="font-mono px-2 py-0.5 rounded bg-gray-100 mr-2">{method}</span>
      <span className="font-mono">{route}</span>
    </div>
    {examples.map((ex, i) => (
      <Example key={i} {...ex} />
    ))}
  </div>
);

export default function Docs() {
  const user = useAuth();
  const base = `http://localhost:8467/profils`;

  // ---- USER SECTIONS (-1, -4, -5) ----
  const userSections = [
    {//done
      title: "Route 1: Ajout d’utilisateur",
      method: "POST",
      route: "/profils",
      desc:
        "Crée un utilisateur (pseudo, courriel, mot de passe, rôle). L’email est validé via API externe. Route publique.",
      examples: [
        {
          title: "Exemple 1 — Email invalide :",
          curl: `curl -s -X POST ${base} \\
    -H "Content-Type: application/json" \\
    -d '{ "name":"Alice", "email":"alice@example.com", "password":"Secret123", "role":"employee" }'`,
          response: `{"message":"Adresse email invalide."}`
        },
        {
          title: "Exemple 2 — Email déjà utilisé :",
          curl: `curl -s -X POST ${base} \\
  -H "Content-Type: application/json" \\
  -d '{ "name":"Reem", "email":"reemhabib25.3@gmail.com", "password":"Secret123", "role":"employee" }'`,
          response: `{"message":"Cet email est déjà utilisé."}`
        },
        {
          title: "Exemple 3 — Succès :",
          curl: `curl -s -X POST ${base} \\
  -H "Content-Type: application/json" \\
  -d '{ "name":"Tai", "email":"taifoster05@gmail.com", "password":"Secret123", "role":"admin" }'`,
          response: `{"alert":"Email validé, inscription réussie !!", \\
"token":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6IjY4OTZhNTVkN2FmODk1ZDBjYjBkNTkwMSIsImlhdCI6MTc1NDcwMzE5NywiZXhwIjoxNzU0NzA2Nzk3fQ.VqNe4ZnpQTqdZh1P3jEa2Ll4dk_-kBHShpaTRIEdgx0", \\
"user":{"id":"6896a55d7af895d0cb0d5901", \\
"name":"Tai",  \\
"email":"taifoster05@gmail.com",  \\
"role":"admin"}}`
        }
      ]
    },

    // Changement de rouuuute
    { //done
      title: "Route 4: Lecture d’un seul profil par Id",
      method: "GET",
      route: "/profils/{id}",
      desc:
        "Retourne un utilisateur (ID, pseudo, courriel, rôle, dates). Autorisé pour l’admin ou pour soi-même.",
      examples: [
        {
          curl: `ID="6896a55d7af895d0cb0d5901"
curl -s ${base}/68967766a919c066571f7eca \\
    -H "Authorization: Bearer $TOKEN"`,
          response: `{"_id":"6896a55d7af895d0cb0d5901",
    "name":"Tai",
    "email":"taifoster05@gmail.com",
    "role":"admin",
    "creatAt":"2025-08-09T01:33:17.138Z",
    "updatedAt":"2025-08-09T01:33:17.138Z"}`
        }
      ]
    },

    // new route
    {//done
      title: "Route 5: Modification d’un profil",
      method: "PUT",
      route: "/profils/{id}",
      desc:
        "Modifie un utilisateur (tous les champs sauf l'ID). Autorisé pour l’admin ou pour soi-même.",
      examples: [
        {
          title: "Changer nom + rôle",
          curl: `ID="68966f9573fc8d6a14289528"
curl -s -X PUT ${base}/68967766a919c066571f7eca \\
  -H "Authorization: Bearer $TOKEN" \\
  -H "Content-Type: application/json" \\
  -d '{ "name":"Riri", "role":"admin" }'`,
          response: `{"_id":"68966f9573fc8d6a14289528",
    "name":"Riri","email":"reemhabib25.3@gmail.com",
    "role":"admin",
    "creatAt":"2025-08-08T21:43:49.874Z",
    "updatedAt":"2025-08-09T02:44:14.650Z"}`
        }
      ]
    }
  ];

  // ---- ADMIN SECTIONS ----
  const adminSections = [
    ...userSections,
    { //done
      title: "Route 2: Suppression d'un profil",
      method: "DELETE",
      route: "/profils/{id}",
      desc: "Supprime un utilisateur (admin uniquement).",
      examples: [
        {
          curl: `ID="68932b0cc8cdd4f52b38b76b"
Token:"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6IjY4OTY3NzY2YTkxOWMwNjY1NzFmN2VjYSIsImlhdCI6MTc1NDcwNjEyOCwiZXhwIjoxNzU0NzA5NzI4fQ.n3OlfcjfmvAWBKIUHEEI5mJLZm-8Y39Pxv_3CVaei6M", 
curl -s -X DELETE ${base}/68967766a919c066571f7eca \\
  -H "Authorization: Bearer $TOKEN"`,
          response: `{"message":"Deleted","user":{"_id":"68932b0cc8cdd4f52b38b76b", \\
    "name":"papa","email":"papa@gmail.com","role":"admin"}}`
        }
      ]
    },
    { //done
      title: "Route 3: Lecture de tous les profils",
      method: "GET",
      route: "/profils",
      desc: "Liste tous les utilisateurs (admin uniquement).",
      examples: [
        {
          curl: `curl -s ${base} \\
  -H "Authorization: Bearer $TOKEN"`,
          response: `[{"_id":"68963190c4cab904bd0be28c","name":"Reem Hab","email":"reemhabib10.3@gmail.com","role":"admin","creatAt":"2025-08-08T17:19:12.588Z","updatedAt":"2025-08-09T02:35:16.695Z"},
{"_id":"68966f7573fc8d6a14289522","name":"Reem Habib","email":"reem.habib@umontreal.ca","role":"employee","creatAt":"2025-08-08T21:43:17.287Z","updatedAt":"2025-08-09T00:08:18.678Z"},
{"_id":"68966f9573fc8d6a14289528","name":"euh","email":"reemhabib25.3@gmail.com","role":"employee","creatAt":"2025-08-08T21:43:49.874Z","updatedAt":"2025-08-08T21:43:49.874Z"},
{"_id":"68966fc073fc8d6a1428952e","name":"bibi","email":"bibi@hotmail.fr","role":"employee","creatAt":"2025-08-08T21:44:32.574Z","updatedAt":"2025-08-08T21:44:32.574Z"},
{"_id":"68967615a919c066571f7ec4","name":"Reem2","email":"reemhabib@hotmail.fr","role":"employee","creatAt":"2025-08-08T22:11:33.327Z","updatedAt":"2025-08-08T22:11:33.327Z"},
{"_id":"68967766a919c066571f7eca","name":"Khalid Habib","email":"habibkhalid1937@gmail.com","role":"admin","creatAt":"2025-08-08T22:17:10.605Z","updatedAt":"2025-08-08T22:17:10.605Z"},
{"_id":"6896a55d7af895d0cb0d5901","name":"Tai","email":"taifoster05@gmail.com","role":"admin","creatAt":"2025-08-09T01:33:17.138Z","updatedAt":"2025-08-09T01:33:17.138Z"}]`
        }
      ]
    }
  ];

  if (user === undefined) return <div>Chargement…</div>;
  if (!user) return <div className="p-8">Veuillez vous connecter pour consulter la documentation.</div>;

  const sections = user.role === "admin" ? adminSections : userSections;

  return (
    <div className="p-4 max-w-5xl mx-auto space-y-6">
      <h1 className="text-2xl font-bold">Documentation de l’API REST</h1>
      <p className="text-gray-700">
        Base: <span className="font-mono">{base}</span>
      </p>

      {sections.map((s, i) => (
        <Section key={i} {...s} />
      ))}
    </div>
  );
}