import React, { useState } from "react";
import API from "../api.js";
import { useNavigate } from "react-router-dom";

export default function ListProfils() {
  const [users, setUsers] = useState([]);
  const [one, setOne] = useState(null);
  const [id, setId] = useState("");
  const [loadingAll, setLoadingAll] = useState(false);
  const [loadingOne, setLoadingOne] = useState(false);
  const navigate = useNavigate();

  const loadAll = async () => {
    setUsers([]);
    setOne(null);
    try {
      setLoadingAll(true);
      const res = await API.get(""); // GET /profils
      setUsers(res.data);
    } catch (e) {
      alert(e.response?.data?.message || "Erreur chargement");
    } finally {
      setLoadingAll(false);
    }
  };

  const loadOne = async (e) => {
    e.preventDefault();
    setUsers([]);
    setOne(null);
    if (!id.trim()) return;
    try {
      setLoadingOne(true);
      const res = await API.get(`/${id.trim()}`); // GET /profils/:id
      setOne(res.data);
    } catch (e) {
      alert(e.response?.data?.message || "Utilisateur introuvable");
    } finally {
      setLoadingOne(false);
    }
  };

  const deleteById = async (userId, label) => {
    const ok = window.confirm(`Voulez-vous vraiment supprimer ${label} ?`);
    if (!ok) return;
    await API.delete(`/${userId}`); // DELETE /profils/:id
  };

  return (
    <div className="p-4">
      <h1 className="text-xl font-bold mb-4">Lecture de la base</h1>

      <div className="flex flex-wrap gap-4 mb-4">
        <button
          onClick={loadAll}
          className="px-4 py-2 bg-blue-600 text-white rounded"
          disabled={loadingAll}
        >
          {loadingAll ? "Chargement..." : "Afficher tous les profils"}
        </button>

        <form onSubmit={loadOne} className="flex gap-2 items-center">
          <input
            className="border p-2"
            placeholder="ID utilisateur"
            value={id}
            onChange={(e) => setId(e.target.value)}
          />
          <button className="px-4 py-2 bg-gray-700 text-white rounded" disabled={loadingOne}>
            {loadingOne ? "..." : "Afficher par ID"}
          </button>
        </form>
      </div>

      {/* Carte pour un seul utilisateur (via ID) */}
      {one && (
        <div className="border p-4 rounded bg-white mb-6">
          <h2 className="font-semibold mb-2">Utilisateur</h2>
          <ul className="list-disc pl-5">
            <li>ID: {one._id}</li>
            <li>Nom: {one.name}</li>
            <li>Email: {one.email}</li>
            <li>Rôle: {one.role}</li>
            <li>Créé le: {new Date(one.creatAt).toLocaleString()}</li>
          </ul>
          <div className="mt-3 space-x-2">
            <button onClick={() => navigate(`/view/${one._id}`)} className="px-3 py-1 bg-blue-600 text-white rounded">
              Voir
            </button>
            <button onClick={() => navigate(`/edit/${one._id}`)} className="px-3 py-1 bg-green-600 text-white rounded">
              Éditer
            </button>
            <button
              onClick={async () => {
                try {
                  await deleteById(one._id, `${one.name} (${one.email})`);
                  setOne(null);
                  setId("");
                  alert("Utilisateur supprimé.");
                } catch (e) {
                  alert(e.response?.data?.message || "Erreur suppression");
                }
              }}
              className="px-3 py-1 bg-red-600 text-white rounded"
            >
              Supprimer
            </button>
          </div>
        </div>
      )}

      {/* Tableau “Afficher tous” */}
      {users.length > 0 && (
        <table className="min-w-full bg-white border">
          <thead>
            <tr className="border-b">
              <th className="p-2">ID</th>
              <th className="p-2">Nom</th>
              <th className="p-2">Email</th>
              <th className="p-2">Rôle</th>
              <th className="p-2">Actions</th>
            </tr>
          </thead>
          <tbody>
            {users.map((u) => (
              <tr key={u._id} className="border-b">
                <td className="p-2">{u._id}</td>
                <td className="p-2">{u.name}</td>
                <td className="p-2">{u.email}</td>
                <td className="p-2">{u.role}</td>
                <td className="p-2 space-x-2">
                  <button
                    onClick={() => navigate(`/view/${u._id}`)}
                    className="px-2 py-1 bg-blue-600 text-white rounded"
                  >
                    Voir
                  </button>
                  <button
                    onClick={() => navigate(`/edit/${u._id}`)}
                    className="px-2 py-1 bg-green-600 text-white rounded"
                  >
                    Éditer
                  </button>
                  <button
                    onClick={async () => {
                      try {
                        await deleteById(u._id, `${u.name} (${u.email})`);
                        setUsers((prev) => prev.filter((x) => x._id !== u._id));
                        alert("Utilisateur supprimé.");
                      } catch (e) {
                        alert(e.response?.data?.message || "Erreur suppression");
                      }
                    }}
                    className="px-2 py-1 bg-red-600 text-white rounded"
                  >
                    Supprimer
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
}