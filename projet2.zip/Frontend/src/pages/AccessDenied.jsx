export default function AccessDenied() {
    return (
      <div className="p-8 text-center">
        <h1 className="text-2xl font-bold mb-2">Accès refusé</h1>
        <p>Vous ne pouvez pas accéder à cette page.</p>
        <p> Elle est réservée aux admins seulement</p>
      </div>
    );
  }