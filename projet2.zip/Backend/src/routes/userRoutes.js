import express from "express";
import {
  register,
  login,
  listUsers,
  getMe,
  getUser,
  updateUser,
  deleteUser,
  generatePassword,
} from "../controllers/userController.js";
import { protect } from "../middleware/auth.js";
import { adminCheck } from "../middleware/rolecheck.js";
const router = express.Router();

// Public routes
router.get("/motdepasse/:length", generatePassword);
router.post("/", register);
router.post("/login", login);

// Protected routes
router.get("/me", protect, getMe);
router.get("/", protect, adminCheck, listUsers);
router.get("/:id", protect, getUser);
router.put("/:id", protect, updateUser);
router.delete("/:id", protect, adminCheck, deleteUser);

export { router as default };
