import User from "../models/user.js";
import bcrypt from "bcrypt";
import jwt from "jsonwebtoken";

// Maileroo/Zeruh email validation
const verifyEmailAPI = async (email) => {
  const base = process.env.MAILEROO_API_URL;
  const key = process.env.MAILEROO_API_KEY;
  if (!base || !key) return false;

  const url = `${base}?api_key=${encodeURIComponent(key)}&email_address=${encodeURIComponent(email)}`;
  const res = await fetch(url, { headers: { Accept: 'application/json' } });
  const data = await res.json().catch(() => ({}));

  // Le data.result.status inclus 4 états soit deliverable, risky, undeliverable ou nknown
  const status = data?.result?.status || data?.status || null;
  return status === 'deliverable';
};

// POST /profils
export const register = async (req, res) => {
  const { name, email, password, role } = req.body;
  try {
    if (await User.findOne({ email })) {
      return res.status(400).json({ message: "Cet email est déjà utilisé" });
    }

    const ok = await verifyEmailAPI(email);
    if (!ok) {
      return res.status(422).json({ message: "Adresse email invalide" });
    }

    const user = new User({ name, email, password, role });
    await user.save();

    const token = jwt.sign({ id: user._id }, process.env.JWT_SECRET, { expiresIn: "1h" });

    return res.status(201).json({
      alert: "Email validé, inscription réussie !!",
      token,
      user: { id: user._id, name: user.name, email: user.email, role: user.role },
    });
  } catch (error) {
    console.error("Register error:", error);
    return res.status(500).json({ message: "Erreur du serveur" });
  }
};

// POST /profils/login
export const login = async (req, res) => {
  const { email, password } = req.body;
  try {
    const user = await User.findOne({ email });
    if (!user)
      return res.status(400).json({ message: "Invalid credentials" });
    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch)
      return res.status(400).json({ message: "Invalid credentials" });
    const token = jwt.sign({ id: user._id }, process.env.JWT_SECRET, {
      expiresIn: "1h",
    });
    res.json({ token });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// GET /profils
export const listUsers = async (req, res) => {
  const users = await User.find().select("_id name email role creatAt updatedAt");
  res.json(users);
};

// GET /profils/me
export const getMe = async (req, res) => {
  // req.user est fourni par le middleware protect
  res.json({
    _id: req.user._id,
    name: req.user.name,
    email: req.user.email,
    role: req.user.role,
    creatAt: req.user.creatAt,
    updatedAt: req.user.updatedAt,
  });
};

// GET /profils/:id
export const getUser = async (req, res) => {
   // Si pas admin, tu ne peux lire que ton propre profil
   if (req.user.role !== "admin" && String(req.user._id) !== String(req.params.id)) {
    return res.status(403).json({ message: "Forbidden" });
  }

  const user = await User.findById(req.params.id).select(
    "_id name email role creatAt updatedAt"
  );
  if (!user) return res.status(404).json({ message: "Not found" });
  res.json(user);
};

// PUT /profils/:id
export const updateUser = async (req, res) => {
   // Si pas admin, tu ne peux modifier que ton propre profil
   if (req.user.role !== "admin" && String(req.user._id) !== String(req.params.id)) {
    return res.status(403).json({ message: "Forbidden" });
  }

  const { name, email, role, password } = req.body;
  try {
    let updateData = { name, email, role, updatedAt: Date.now() };
    if (password) {
      const salt = await bcrypt.genSalt(10);
      updateData.password = await bcrypt.hash(password, salt);
    }
    
    // Si l'email change, on re-valide avec notre API
    if (email) {
      // Empêche de prendre un email déjà utilisé par un autre compte
      const exists = await User.findOne({ email, _id: { $ne: req.params.id } });
      if (exists) {
        return res.status(400).json({ message: "Email already exists" });
      }
      const isValid = await verifyEmailAPI(email);
      if (!isValid) {
        return res.status(400).json({ message: "Invalid email address" });
      }
    }
    
    const user = await User.findByIdAndUpdate(req.params.id, updateData, {
      new: true,
    }).select("_id name email role creatAt updatedAt");

    if (!user) return res.status(404).json({ message: "Not found" });
    res.json(user);
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
};

// DELETE /profils/:id
export const deleteUser = async (req, res) => {
  const user = await User.findByIdAndDelete(req.params.id).select(
    "_id name email role"
  );
  if (!user) return res.status(404).json({ message: "Not found" });
  res.json({ message: "Deleted", user });
};


// GET /profils/motdepasse/:length
export const generatePassword = (req, res) => {
  const length = parseInt(req.params.length, 10);
  const chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
  let password = "";
  for (let i = 0; i < length; i++) {
    password += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  res.json({ password });
};